Validation Annotations on product
 http://localhost:8091/webstore07/products/add
 
 Custom annotation for ProductId.- add product with id= P1234 - already exists throws exception
  Custom annotation for cross field.- add unit price and units in stock 
  such that the product is > 20000
  
"Manual" validation
http://localhost:8091/webstore07/members/add
NOTE: see controller code for details [ as well as MemberValidator implements validator]